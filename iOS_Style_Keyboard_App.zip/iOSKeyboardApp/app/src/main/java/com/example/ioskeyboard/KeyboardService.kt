// Kotlin service class for custom keyboard
